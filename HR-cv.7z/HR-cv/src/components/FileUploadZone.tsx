/**
 * FileUploadZone Component
 * A drag-and-drop file upload zone with visual feedback
 */

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, FileText, X, CheckCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getFileType } from '@/lib/textExtractor';

interface FileUploadZoneProps {
  label: string;
  description: string;
  file: File | null;
  onFileSelect: (file: File) => void;
  onFileClear: () => void;
  variant?: 'cv' | 'jd';
}

export function FileUploadZone({
  label,
  description,
  file,
  onFileSelect,
  onFileClear,
  variant = 'cv'
}: FileUploadZoneProps) {
  const [isDragging, setIsDragging] = useState(false);

  // Handle file drop
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      const fileType = getFileType(droppedFile.name);
      if (fileType !== 'unknown') {
        onFileSelect(droppedFile);
      }
    }
  }, [onFileSelect]);

  // Handle file input change
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      onFileSelect(selectedFile);
    }
  };

  // Handle drag events
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-semibold text-foreground">
        {label}
      </label>
      
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className={cn(
          "relative rounded-xl border-2 border-dashed transition-all duration-300",
          "min-h-[160px] flex flex-col items-center justify-center p-6",
          isDragging && "border-primary bg-primary/5 scale-[1.02]",
          file && "border-success bg-success/5",
          !isDragging && !file && "border-border hover:border-primary/50 hover:bg-muted/50",
          variant === 'cv' ? 'hover:shadow-glow' : 'hover:shadow-accent-glow'
        )}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
      >
        <AnimatePresence mode="wait">
          {file ? (
            <motion.div
              key="file-selected"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex flex-col items-center gap-3"
            >
              <div className="flex items-center gap-2 px-4 py-2 bg-success/10 rounded-lg">
                <CheckCircle className="w-5 h-5 text-success" />
                <span className="text-sm font-medium text-success">File Selected</span>
              </div>
              
              <div className="flex items-center gap-2 px-3 py-2 bg-card rounded-lg border border-border">
                <FileText className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-foreground truncate max-w-[200px]">
                  {file.name}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onFileClear();
                  }}
                  className="ml-2 p-1 hover:bg-destructive/10 rounded-full transition-colors"
                >
                  <X className="w-4 h-4 text-destructive" />
                </button>
              </div>
              
              <span className="text-xs text-muted-foreground">
                {(file.size / 1024).toFixed(1)} KB
              </span>
            </motion.div>
          ) : (
            <motion.div
              key="upload-prompt"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-3 text-center"
            >
              <motion.div
                animate={{ y: isDragging ? -5 : 0 }}
                transition={{ type: 'spring', stiffness: 300 }}
                className={cn(
                  "p-4 rounded-full",
                  variant === 'cv' ? 'bg-primary/10' : 'bg-accent/10'
                )}
              >
                <Upload className={cn(
                  "w-8 h-8",
                  variant === 'cv' ? 'text-primary' : 'text-accent'
                )} />
              </motion.div>
              
              <div>
                <p className="text-sm font-medium text-foreground">
                  {isDragging ? 'Drop your file here' : 'Drag & drop or click to upload'}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {description}
                </p>
              </div>
              
              <div className="flex gap-2">
                {['PDF', 'DOCX', 'TXT'].map((type) => (
                  <span
                    key={type}
                    className="px-2 py-1 text-xs bg-muted rounded-md text-muted-foreground"
                  >
                    {type}
                  </span>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Hidden file input */}
        <input
          type="file"
          accept=".pdf,.docx,.txt"
          onChange={handleFileChange}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
      </motion.div>
    </div>
  );
}
