/**
 * DecisionBanner Component
 * Displays the shortlisting decision with appropriate styling
 */

import { motion } from 'framer-motion';
import { ThumbsUp, AlertTriangle, ThumbsDown, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DecisionBannerProps {
  decision: 'strong' | 'moderate' | 'weak';
  decisionText: string;
}

export function DecisionBanner({ decision, decisionText }: DecisionBannerProps) {
  const config = {
    strong: {
      icon: ThumbsUp,
      bgClass: 'bg-gradient-to-r from-success/20 to-success/5',
      borderClass: 'border-success/30',
      textClass: 'text-success',
      iconBgClass: 'bg-success/20'
    },
    moderate: {
      icon: AlertTriangle,
      bgClass: 'bg-gradient-to-r from-warning/20 to-warning/5',
      borderClass: 'border-warning/30',
      textClass: 'text-warning',
      iconBgClass: 'bg-warning/20'
    },
    weak: {
      icon: ThumbsDown,
      bgClass: 'bg-gradient-to-r from-destructive/20 to-destructive/5',
      borderClass: 'border-destructive/30',
      textClass: 'text-destructive',
      iconBgClass: 'bg-destructive/20'
    }
  };

  const currentConfig = config[decision];
  const Icon = currentConfig.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className={cn(
        "relative overflow-hidden rounded-xl border p-6",
        currentConfig.bgClass,
        currentConfig.borderClass
      )}
    >
      {/* Decorative sparkles for strong decision */}
      {decision === 'strong' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="absolute top-3 right-3"
        >
          <Sparkles className="w-5 h-5 text-success/50" />
        </motion.div>
      )}

      <div className="flex items-center gap-4">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 200, delay: 0.5 }}
          className={cn(
            "p-3 rounded-full",
            currentConfig.iconBgClass
          )}
        >
          <Icon className={cn("w-6 h-6", currentConfig.textClass)} />
        </motion.div>

        <div>
          <motion.p
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            className="text-sm font-medium text-muted-foreground"
          >
            Shortlisting Decision
          </motion.p>
          <motion.h3
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.7 }}
            className={cn("text-lg font-bold", currentConfig.textClass)}
          >
            {decisionText}
          </motion.h3>
        </div>
      </div>
    </motion.div>
  );
}
