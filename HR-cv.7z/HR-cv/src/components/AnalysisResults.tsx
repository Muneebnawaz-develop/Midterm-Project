/**
 * AnalysisResults Component
 * Main component for displaying CV-JD analysis results
 */

import { motion } from 'framer-motion';
import { Download, RotateCcw, BarChart2, Target, GraduationCap, Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScoreCircle } from './ScoreCircle';
import { SkillBadge } from './SkillBadge';
import { DecisionBanner } from './DecisionBanner';
import { SummaryCard } from './SummaryCard';
import { generatePDFReport } from '@/lib/pdfGenerator';
import type { AnalysisResult } from '@/lib/nlpProcessor';

interface AnalysisResultsProps {
  result: AnalysisResult;
  cvFileName: string;
  jdFileName: string;
  onReset: () => void;
}

export function AnalysisResults({
  result,
  cvFileName,
  jdFileName,
  onReset
}: AnalysisResultsProps) {
  // Handle PDF download
  const handleDownloadReport = () => {
    generatePDFReport({
      cvFileName,
      jdFileName,
      analysisDate: new Date().toLocaleString(),
      result
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="max-w-4xl mx-auto space-y-8"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <motion.h1
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-display text-2xl sm:text-3xl font-bold text-foreground"
          >
            Analysis Results
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-muted-foreground mt-1"
          >
            {cvFileName} vs {jdFileName}
          </motion.p>
        </div>

        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onReset}
            className="gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            New Analysis
          </Button>
          <Button
            onClick={handleDownloadReport}
            className="gap-2 bg-primary hover:bg-primary/90"
          >
            <Download className="w-4 h-4" />
            Download Report
          </Button>
        </div>
      </div>

      {/* Main Score Section */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-card rounded-2xl border border-border p-8 shadow-lg"
      >
        <div className="flex flex-col md:flex-row items-center gap-8">
          {/* Overall Score */}
          <div className="flex-shrink-0">
            <ScoreCircle score={result.overallScore} size="lg" />
          </div>

          {/* Score Breakdown */}
          <div className="flex-1 w-full">
            <h3 className="font-display font-bold text-lg text-foreground mb-4 flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-primary" />
              Score Breakdown
            </h3>
            
            <div className="grid grid-cols-3 gap-4">
              <ScoreBreakdownItem
                icon={Target}
                label="Skills"
                score={result.skillsScore}
              />
              <ScoreBreakdownItem
                icon={Briefcase}
                label="Experience"
                score={result.experienceScore}
              />
              <ScoreBreakdownItem
                icon={GraduationCap}
                label="Education"
                score={result.educationScore}
              />
            </div>
          </div>
        </div>
      </motion.div>

      {/* Decision Banner */}
      <DecisionBanner
        decision={result.decision}
        decisionText={result.decisionText}
      />

      {/* Skills Analysis */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-card rounded-xl border border-border p-6 shadow-sm"
      >
        <h3 className="font-display font-bold text-lg text-foreground mb-6 flex items-center gap-2">
          <Target className="w-5 h-5 text-primary" />
          Skills Analysis
        </h3>

        <div className="space-y-6">
          {/* Matching Skills */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-sm font-semibold text-success">
                Matching Skills ({result.matchingSkills.length})
              </span>
              <div className="flex-1 h-px bg-success/20" />
            </div>
            <div className="flex flex-wrap gap-2">
              {result.matchingSkills.length > 0 ? (
                result.matchingSkills.map((skill, index) => (
                  <SkillBadge
                    key={skill}
                    skill={skill}
                    variant="matching"
                    index={index}
                  />
                ))
              ) : (
                <span className="text-sm text-muted-foreground italic">
                  No matching skills found
                </span>
              )}
            </div>
          </div>

          {/* Missing Skills */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-sm font-semibold text-destructive">
                Missing Skills ({result.missingSkills.length})
              </span>
              <div className="flex-1 h-px bg-destructive/20" />
            </div>
            <div className="flex flex-wrap gap-2">
              {result.missingSkills.length > 0 ? (
                result.missingSkills.map((skill, index) => (
                  <SkillBadge
                    key={skill}
                    skill={skill}
                    variant="missing"
                    index={index}
                  />
                ))
              ) : (
                <span className="text-sm text-muted-foreground italic">
                  All required skills present
                </span>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* HR Summary & Strengths/Weaknesses */}
      <SummaryCard
        summary={result.summary}
        strengths={result.strengths}
        weaknesses={result.weaknesses}
      />

      {/* Experience & Education Details */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="grid md:grid-cols-2 gap-4"
      >
        {/* Experience */}
        <div className="bg-card rounded-xl border border-border p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <Briefcase className="w-5 h-5 text-primary" />
            <h4 className="font-semibold text-foreground">Experience</h4>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">CV Experience:</span>
              <span className="font-medium text-foreground">
                {result.cvExperience !== null ? `${result.cvExperience}+ years` : 'Not specified'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">JD Requirement:</span>
              <span className="font-medium text-foreground">
                {result.jdExperience !== null ? `${result.jdExperience}+ years` : 'Not specified'}
              </span>
            </div>
          </div>
        </div>

        {/* Education */}
        <div className="bg-card rounded-xl border border-border p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <GraduationCap className="w-5 h-5 text-primary" />
            <h4 className="font-semibold text-foreground">Education</h4>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {result.cvEducation.length > 0 ? (
              result.cvEducation.map((edu) => (
                <span
                  key={edu}
                  className="px-2 py-1 bg-muted text-xs rounded-md text-foreground capitalize"
                >
                  {edu}
                </span>
              ))
            ) : (
              <span className="text-sm text-muted-foreground italic">
                No education details found
              </span>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

// Score breakdown item component
function ScoreBreakdownItem({
  icon: Icon,
  label,
  score
}: {
  icon: React.ElementType;
  label: string;
  score: number;
}) {
  const getScoreColor = () => {
    if (score >= 70) return 'text-success';
    if (score >= 40) return 'text-warning';
    return 'text-destructive';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="text-center p-4 bg-muted/50 rounded-xl"
    >
      <Icon className="w-5 h-5 text-muted-foreground mx-auto mb-2" />
      <div className={`text-2xl font-bold ${getScoreColor()}`}>
        {score}%
      </div>
      <div className="text-xs text-muted-foreground mt-1">{label}</div>
    </motion.div>
  );
}
