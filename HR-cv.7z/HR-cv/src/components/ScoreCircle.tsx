/**
 * ScoreCircle Component
 * Animated circular progress indicator for displaying match scores
 */

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ScoreCircleProps {
  score: number;
  size?: 'sm' | 'md' | 'lg';
  label?: string;
  showPercentage?: boolean;
}

export function ScoreCircle({
  score,
  size = 'lg',
  label,
  showPercentage = true
}: ScoreCircleProps) {
  const [animatedScore, setAnimatedScore] = useState(0);
  
  // Animate score on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedScore(score);
    }, 100);
    return () => clearTimeout(timer);
  }, [score]);

  // Size configurations
  const sizeConfig = {
    sm: { width: 80, strokeWidth: 6, fontSize: 'text-lg', labelSize: 'text-xs' },
    md: { width: 120, strokeWidth: 8, fontSize: 'text-2xl', labelSize: 'text-sm' },
    lg: { width: 180, strokeWidth: 12, fontSize: 'text-4xl', labelSize: 'text-base' }
  };

  const config = sizeConfig[size];
  const radius = (config.width - config.strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (animatedScore / 100) * circumference;

  // Color based on score
  const getScoreColor = () => {
    if (score >= 70) return 'stroke-success';
    if (score >= 40) return 'stroke-warning';
    return 'stroke-destructive';
  };

  const getScoreTextColor = () => {
    if (score >= 70) return 'text-success';
    if (score >= 40) return 'text-warning';
    return 'text-destructive';
  };

  return (
    <div className="flex flex-col items-center gap-2">
      <div 
        className="relative"
        style={{ width: config.width, height: config.width }}
      >
        <svg
          className="transform -rotate-90"
          width={config.width}
          height={config.width}
        >
          {/* Background circle */}
          <circle
            cx={config.width / 2}
            cy={config.width / 2}
            r={radius}
            strokeWidth={config.strokeWidth}
            className="fill-none stroke-muted"
          />
          
          {/* Progress circle */}
          <motion.circle
            cx={config.width / 2}
            cy={config.width / 2}
            r={radius}
            strokeWidth={config.strokeWidth}
            className={cn("fill-none", getScoreColor())}
            strokeLinecap="round"
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            style={{
              strokeDasharray: circumference,
            }}
          />
        </svg>
        
        {/* Score text in center */}
        {showPercentage && (
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <motion.span
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
              className={cn("font-display font-bold", config.fontSize, getScoreTextColor())}
            >
              {Math.round(animatedScore)}%
            </motion.span>
            {label && size === 'lg' && (
              <span className="text-xs text-muted-foreground mt-1">
                Match Score
              </span>
            )}
          </div>
        )}
      </div>
      
      {label && size !== 'lg' && (
        <span className={cn("text-muted-foreground font-medium", config.labelSize)}>
          {label}
        </span>
      )}
    </div>
  );
}
