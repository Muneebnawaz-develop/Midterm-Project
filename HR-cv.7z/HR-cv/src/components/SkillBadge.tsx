/**
 * SkillBadge Component
 * Displays a skill with visual styling based on match status
 */

import { motion } from 'framer-motion';
import { Check, X, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SkillBadgeProps {
  skill: string;
  variant: 'matching' | 'missing' | 'neutral';
  index?: number;
}

export function SkillBadge({ skill, variant, index = 0 }: SkillBadgeProps) {
  const variantStyles = {
    matching: 'bg-success/10 text-success border-success/30 hover:bg-success/20',
    missing: 'bg-destructive/10 text-destructive border-destructive/30 hover:bg-destructive/20',
    neutral: 'bg-muted text-muted-foreground border-border hover:bg-muted/80'
  };

  const icons = {
    matching: Check,
    missing: X,
    neutral: AlertCircle
  };

  const Icon = icons[variant];

  return (
    <motion.span
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.05, duration: 0.2 }}
      className={cn(
        "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium",
        "border transition-colors cursor-default",
        variantStyles[variant]
      )}
    >
      <Icon className="w-3.5 h-3.5" />
      <span className="capitalize">{skill}</span>
    </motion.span>
  );
}
