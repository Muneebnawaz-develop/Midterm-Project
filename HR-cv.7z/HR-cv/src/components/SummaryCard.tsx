/**
 * SummaryCard Component
 * Displays HR summary, strengths, and weaknesses
 */

import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, FileText } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SummaryCardProps {
  summary: string;
  strengths: string[];
  weaknesses: string[];
}

export function SummaryCard({ summary, strengths, weaknesses }: SummaryCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="space-y-6"
    >
      {/* HR Summary */}
      <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <div className="p-2 bg-primary/10 rounded-lg">
            <FileText className="w-5 h-5 text-primary" />
          </div>
          <h3 className="font-display font-bold text-lg text-foreground">
            HR Summary
          </h3>
        </div>
        <p className="text-muted-foreground leading-relaxed">
          {summary}
        </p>
      </div>

      {/* Strengths & Weaknesses Grid */}
      <div className="grid md:grid-cols-2 gap-4">
        {/* Strengths */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-success/5 rounded-xl border border-success/20 p-5"
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="p-2 bg-success/20 rounded-lg">
              <TrendingUp className="w-4 h-4 text-success" />
            </div>
            <h4 className="font-semibold text-success">Strengths</h4>
          </div>
          
          {strengths.length > 0 ? (
            <ul className="space-y-2">
              {strengths.map((strength, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className="flex items-start gap-2 text-sm text-foreground"
                >
                  <span className="text-success mt-1">•</span>
                  <span>{strength}</span>
                </motion.li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground italic">
              No specific strengths identified
            </p>
          )}
        </motion.div>

        {/* Weaknesses */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-destructive/5 rounded-xl border border-destructive/20 p-5"
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="p-2 bg-destructive/20 rounded-lg">
              <TrendingDown className="w-4 h-4 text-destructive" />
            </div>
            <h4 className="font-semibold text-destructive">Areas for Improvement</h4>
          </div>
          
          {weaknesses.length > 0 ? (
            <ul className="space-y-2">
              {weaknesses.map((weakness, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className="flex items-start gap-2 text-sm text-foreground"
                >
                  <span className="text-destructive mt-1">•</span>
                  <span>{weakness}</span>
                </motion.li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground italic">
              No critical weaknesses identified
            </p>
          )}
        </motion.div>
      </div>
    </motion.div>
  );
}
