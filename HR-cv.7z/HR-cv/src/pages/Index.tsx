/**
 * HR CV-JD Match Assistant - Main Page
 * Upload CVs and Job Descriptions to analyze match scores
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileSearch, Loader2, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FileUploadZone } from '@/components/FileUploadZone';
import { AnalysisResults } from '@/components/AnalysisResults';
import { extractText } from '@/lib/textExtractor';
import { analyzeMatch, type AnalysisResult } from '@/lib/nlpProcessor';
import { toast } from '@/hooks/use-toast';

const Index = () => {
  const [cvFile, setCvFile] = useState<File | null>(null);
  const [jdFile, setJdFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  // Handle analysis
  const handleAnalyze = async () => {
    if (!cvFile || !jdFile) {
      toast({ title: 'Please upload both CV and Job Description', variant: 'destructive' });
      return;
    }

    setIsAnalyzing(true);
    try {
      const [cvText, jdText] = await Promise.all([
        extractText(cvFile),
        extractText(jdFile)
      ]);

      const analysisResult = analyzeMatch(cvText, jdText);
      setResult(analysisResult);
      toast({ title: 'Analysis Complete!', description: `Match Score: ${analysisResult.overallScore}%` });
    } catch (error) {
      toast({ title: 'Error processing files', description: String(error), variant: 'destructive' });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Reset to upload view
  const handleReset = () => {
    setCvFile(null);
    setJdFile(null);
    setResult(null);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center gap-3">
          <div className="p-2 bg-primary/10 rounded-lg">
            <FileSearch className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="font-display font-bold text-xl text-foreground">CV-JD Match Assistant</h1>
            <p className="text-xs text-muted-foreground">AI-powered resume screening</p>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {result ? (
            <AnalysisResults
              key="results"
              result={result}
              cvFileName={cvFile?.name || 'CV'}
              jdFileName={jdFile?.name || 'JD'}
              onReset={handleReset}
            />
          ) : (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-3xl mx-auto"
            >
              {/* Hero Section */}
              <div className="text-center mb-10">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full mb-4"
                >
                  <Sparkles className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium text-primary">Smart Resume Screening</span>
                </motion.div>
                <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mb-3">
                  Match CVs with Job Descriptions
                </h2>
                <p className="text-muted-foreground max-w-xl mx-auto">
                  Upload a CV and Job Description to get instant match scores, skill gap analysis, and shortlisting recommendations.
                </p>
              </div>

              {/* Upload Section */}
              <div className="bg-card rounded-2xl border border-border p-6 sm:p-8 shadow-lg">
                <div className="grid md:grid-cols-2 gap-6 mb-6">
                  <FileUploadZone
                    label="Candidate CV"
                    description="Upload the candidate's resume"
                    file={cvFile}
                    onFileSelect={setCvFile}
                    onFileClear={() => setCvFile(null)}
                    variant="cv"
                  />
                  <FileUploadZone
                    label="Job Description"
                    description="Upload the job requirements"
                    file={jdFile}
                    onFileSelect={setJdFile}
                    onFileClear={() => setJdFile(null)}
                    variant="jd"
                  />
                </div>

                <Button
                  onClick={handleAnalyze}
                  disabled={!cvFile || !jdFile || isAnalyzing}
                  className="w-full h-12 text-base font-semibold gap-2"
                  size="lg"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <FileSearch className="w-5 h-5" />
                      Analyze Match
                    </>
                  )}
                </Button>
              </div>

              {/* Features */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
                {['Skills Match', 'Experience Check', 'Gap Analysis', 'PDF Report'].map((feature, i) => (
                  <motion.div
                    key={feature}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 + i * 0.1 }}
                    className="text-center p-4 bg-muted/50 rounded-xl"
                  >
                    <span className="text-sm font-medium text-foreground">{feature}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

export default Index;
