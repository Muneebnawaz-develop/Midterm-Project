/**
 * PDF Report Generator Module
 * Generates downloadable PDF reports for CV-JD analysis results
 */

import { jsPDF } from 'jspdf';
import type { AnalysisResult } from './nlpProcessor';

export interface ReportData {
  cvFileName: string;
  jdFileName: string;
  analysisDate: string;
  result: AnalysisResult;
}

/**
 * Generate a PDF report from analysis results
 */
export function generatePDFReport(data: ReportData): void {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  let yPosition = 20;

  // Helper function to add text with word wrap
  const addText = (text: string, x: number, y: number, maxWidth: number, fontSize = 12) => {
    doc.setFontSize(fontSize);
    const lines = doc.splitTextToSize(text, maxWidth);
    doc.text(lines, x, y);
    return y + (lines.length * fontSize * 0.5);
  };

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(24);
  doc.setTextColor(30, 58, 95); // Primary color
  doc.text('CV-JD Match Analysis Report', pageWidth / 2, yPosition, { align: 'center' });
  yPosition += 15;

  // Subtitle
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text(`Generated on ${data.analysisDate}`, pageWidth / 2, yPosition, { align: 'center' });
  yPosition += 15;

  // Horizontal line
  doc.setDrawColor(30, 58, 95);
  doc.setLineWidth(0.5);
  doc.line(20, yPosition, pageWidth - 20, yPosition);
  yPosition += 15;

  // File Information
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(30, 58, 95);
  doc.text('Document Information', 20, yPosition);
  yPosition += 10;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(50, 50, 50);
  doc.text(`CV File: ${data.cvFileName}`, 20, yPosition);
  yPosition += 7;
  doc.text(`JD File: ${data.jdFileName}`, 20, yPosition);
  yPosition += 15;

  // Match Score Section
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(30, 58, 95);
  doc.text('Match Score', 20, yPosition);
  yPosition += 10;

  // Overall Score Box
  doc.setFillColor(240, 240, 240);
  doc.roundedRect(20, yPosition, pageWidth - 40, 25, 3, 3, 'F');
  
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(28);
  
  // Color based on score
  if (data.result.overallScore >= 70) {
    doc.setTextColor(34, 139, 34); // Green
  } else if (data.result.overallScore >= 40) {
    doc.setTextColor(255, 165, 0); // Orange
  } else {
    doc.setTextColor(220, 53, 69); // Red
  }
  
  doc.text(`${data.result.overallScore}%`, 30, yPosition + 17);
  
  doc.setFontSize(12);
  doc.setTextColor(50, 50, 50);
  doc.text(data.result.decisionText, 80, yPosition + 15);
  yPosition += 35;

  // Score Breakdown
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(30, 58, 95);
  doc.text('Score Breakdown:', 20, yPosition);
  yPosition += 8;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(50, 50, 50);
  doc.text(`• Skills Match: ${data.result.skillsScore}%`, 25, yPosition);
  yPosition += 6;
  doc.text(`• Experience Match: ${data.result.experienceScore}%`, 25, yPosition);
  yPosition += 6;
  doc.text(`• Education Match: ${data.result.educationScore}%`, 25, yPosition);
  yPosition += 15;

  // Skills Analysis
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(30, 58, 95);
  doc.text('Skills Analysis', 20, yPosition);
  yPosition += 10;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(34, 139, 34);
  doc.text('Matching Skills:', 20, yPosition);
  yPosition += 7;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(50, 50, 50);
  const matchingText = data.result.matchingSkills.length > 0 
    ? data.result.matchingSkills.join(', ') 
    : 'No matching skills found';
  yPosition = addText(matchingText, 20, yPosition, pageWidth - 40, 10);
  yPosition += 8;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(220, 53, 69);
  doc.text('Missing Skills:', 20, yPosition);
  yPosition += 7;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(50, 50, 50);
  const missingText = data.result.missingSkills.length > 0 
    ? data.result.missingSkills.join(', ') 
    : 'No critical skills missing';
  yPosition = addText(missingText, 20, yPosition, pageWidth - 40, 10);
  yPosition += 15;

  // Check if we need a new page
  if (yPosition > 220) {
    doc.addPage();
    yPosition = 20;
  }

  // Strengths & Weaknesses
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(30, 58, 95);
  doc.text('Strengths & Weaknesses', 20, yPosition);
  yPosition += 10;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(34, 139, 34);
  doc.text('Strengths:', 20, yPosition);
  yPosition += 7;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(50, 50, 50);
  
  if (data.result.strengths.length > 0) {
    data.result.strengths.forEach(strength => {
      yPosition = addText(`• ${strength}`, 25, yPosition, pageWidth - 50, 10);
      yPosition += 4;
    });
  } else {
    doc.text('• No specific strengths identified', 25, yPosition);
    yPosition += 6;
  }
  yPosition += 5;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(220, 53, 69);
  doc.text('Areas for Improvement:', 20, yPosition);
  yPosition += 7;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(50, 50, 50);
  
  if (data.result.weaknesses.length > 0) {
    data.result.weaknesses.forEach(weakness => {
      yPosition = addText(`• ${weakness}`, 25, yPosition, pageWidth - 50, 10);
      yPosition += 4;
    });
  } else {
    doc.text('• No critical weaknesses identified', 25, yPosition);
    yPosition += 6;
  }
  yPosition += 10;

  // Check if we need a new page for summary
  if (yPosition > 230) {
    doc.addPage();
    yPosition = 20;
  }

  // HR Summary
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(30, 58, 95);
  doc.text('HR Summary', 20, yPosition);
  yPosition += 10;

  doc.setFillColor(245, 247, 250);
  
  // Calculate box height based on summary length
  const summaryLines = doc.splitTextToSize(data.result.summary, pageWidth - 50);
  const boxHeight = Math.max(30, summaryLines.length * 6 + 15);
  
  doc.roundedRect(20, yPosition, pageWidth - 40, boxHeight, 3, 3, 'F');
  
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(50, 50, 50);
  doc.text(summaryLines, 25, yPosition + 10);
  yPosition += boxHeight + 15;

  // Footer
  doc.setFontSize(9);
  doc.setTextColor(150, 150, 150);
  doc.text(
    'Generated by HR CV-JD Match Assistant',
    pageWidth / 2,
    doc.internal.pageSize.getHeight() - 10,
    { align: 'center' }
  );

  // Save the PDF
  const fileName = `CV_JD_Analysis_${data.cvFileName.replace(/\.[^/.]+$/, '')}_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(fileName);
}
