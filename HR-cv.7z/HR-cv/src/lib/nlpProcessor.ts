/**
 * NLP Processing Module
 * Handles text preprocessing, keyword extraction, and skill matching
 */

// Common English stopwords to filter out
const STOPWORDS = new Set([
  'a', 'an', 'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
  'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been', 'be', 'have', 'has', 'had',
  'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must',
  'shall', 'can', 'need', 'dare', 'ought', 'used', 'this', 'that', 'these', 'those',
  'i', 'you', 'he', 'she', 'it', 'we', 'they', 'what', 'which', 'who', 'whom',
  'this', 'that', 'am', 'been', 'being', 'each', 'few', 'more', 'most', 'other',
  'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too',
  'very', 'just', 'also', 'now', 'here', 'there', 'when', 'where', 'why', 'how',
  'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such',
  'about', 'into', 'through', 'during', 'before', 'after', 'above', 'below',
  'between', 'under', 'again', 'further', 'then', 'once', 'up', 'down', 'out',
  'off', 'over', 'under', 'again', 'further', 'then', 'once'
]);

// Common technical skills keywords for matching
const SKILL_KEYWORDS = [
  // Programming Languages
  'python', 'javascript', 'typescript', 'java', 'c++', 'c#', 'ruby', 'php', 'swift', 'kotlin',
  'go', 'rust', 'scala', 'perl', 'r', 'matlab', 'sql', 'html', 'css', 'sass', 'less',
  
  // Frameworks & Libraries
  'react', 'angular', 'vue', 'node.js', 'nodejs', 'express', 'django', 'flask', 'spring',
  'laravel', 'rails', 'asp.net', '.net', 'tensorflow', 'pytorch', 'keras', 'pandas',
  'numpy', 'scikit-learn', 'jquery', 'bootstrap', 'tailwind', 'nextjs', 'nuxt',
  
  // Databases
  'mysql', 'postgresql', 'mongodb', 'redis', 'elasticsearch', 'oracle', 'sqlite',
  'cassandra', 'dynamodb', 'firebase', 'supabase', 'graphql',
  
  // Cloud & DevOps
  'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'jenkins', 'git', 'github', 'gitlab',
  'ci/cd', 'terraform', 'ansible', 'linux', 'unix', 'bash', 'powershell',
  
  // Tools & Platforms
  'jira', 'confluence', 'slack', 'trello', 'figma', 'sketch', 'adobe', 'photoshop',
  'illustrator', 'excel', 'powerpoint', 'word', 'salesforce', 'hubspot',
  
  // Concepts & Methodologies
  'agile', 'scrum', 'kanban', 'waterfall', 'tdd', 'bdd', 'oop', 'functional',
  'microservices', 'rest', 'api', 'graphql', 'machine learning', 'ml', 'ai',
  'data science', 'data analysis', 'data visualization', 'big data', 'etl',
  'devops', 'devsecops', 'cybersecurity', 'security', 'networking',
  
  // Soft Skills
  'leadership', 'communication', 'teamwork', 'problem-solving', 'analytical',
  'project management', 'time management', 'critical thinking', 'creativity',
  'adaptability', 'collaboration', 'presentation', 'negotiation', 'mentoring'
];

// Education-related keywords
const EDUCATION_KEYWORDS = [
  'bachelor', 'master', 'phd', 'doctorate', 'degree', 'diploma', 'certificate',
  'university', 'college', 'institute', 'school', 'education', 'graduate',
  'undergraduate', 'postgraduate', 'bsc', 'msc', 'ba', 'ma', 'mba', 'btech',
  'mtech', 'be', 'me', 'bca', 'mca', 'bcom', 'mcom', 'llb', 'llm'
];

// Experience-related patterns
const EXPERIENCE_PATTERNS = [
  /(\d+)\+?\s*(?:years?|yrs?)\s*(?:of\s*)?(?:experience|exp)/gi,
  /experience\s*(?:of\s*)?(\d+)\+?\s*(?:years?|yrs?)/gi,
  /(\d+)\+?\s*(?:years?|yrs?)\s*in/gi
];

// Certification keywords
const CERTIFICATION_KEYWORDS = [
  'certified', 'certification', 'certificate', 'pmp', 'aws certified', 'azure certified',
  'google certified', 'cisco', 'ccna', 'ccnp', 'comptia', 'itil', 'scrum master',
  'six sigma', 'prince2', 'safe', 'togaf', 'cfa', 'cpa', 'acca', 'oracle certified'
];

/**
 * Preprocess text: lowercase, remove punctuation, tokenize
 */
export function preprocessText(text: string): string[] {
  // Convert to lowercase
  let processed = text.toLowerCase();
  
  // Remove special characters but keep spaces and alphanumeric
  processed = processed.replace(/[^a-z0-9\s\+\#\.]/g, ' ');
  
  // Split into tokens
  const tokens = processed.split(/\s+/).filter(token => token.length > 1);
  
  // Remove stopwords
  const filteredTokens = tokens.filter(token => !STOPWORDS.has(token));
  
  return filteredTokens;
}

/**
 * Extract skills from text by matching against known skill keywords
 */
export function extractSkills(text: string): string[] {
  const lowerText = text.toLowerCase();
  const foundSkills: string[] = [];
  
  for (const skill of SKILL_KEYWORDS) {
    // Use word boundary matching to avoid partial matches
    const regex = new RegExp(`\\b${skill.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (regex.test(lowerText)) {
      foundSkills.push(skill);
    }
  }
  
  return [...new Set(foundSkills)]; // Remove duplicates
}

/**
 * Extract education information from text
 */
export function extractEducation(text: string): string[] {
  const lowerText = text.toLowerCase();
  const foundEducation: string[] = [];
  
  for (const edu of EDUCATION_KEYWORDS) {
    const regex = new RegExp(`\\b${edu}\\b`, 'i');
    if (regex.test(lowerText)) {
      foundEducation.push(edu);
    }
  }
  
  return [...new Set(foundEducation)];
}

/**
 * Extract years of experience from text
 */
export function extractExperience(text: string): number | null {
  for (const pattern of EXPERIENCE_PATTERNS) {
    const match = pattern.exec(text);
    if (match) {
      return parseInt(match[1], 10);
    }
    pattern.lastIndex = 0; // Reset regex
  }
  return null;
}

/**
 * Extract certifications from text
 */
export function extractCertifications(text: string): string[] {
  const lowerText = text.toLowerCase();
  const foundCerts: string[] = [];
  
  for (const cert of CERTIFICATION_KEYWORDS) {
    const regex = new RegExp(`\\b${cert.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (regex.test(lowerText)) {
      foundCerts.push(cert);
    }
  }
  
  return [...new Set(foundCerts)];
}

/**
 * Calculate TF-IDF scores for tokens
 */
export function calculateTFIDF(doc1Tokens: string[], doc2Tokens: string[]): { doc1Vector: number[]; doc2Vector: number[] } {
  // Get all unique terms from both documents
  const allTerms = [...new Set([...doc1Tokens, ...doc2Tokens])];
  
  // Calculate term frequency for each document
  const tf1 = new Map<string, number>();
  const tf2 = new Map<string, number>();
  
  doc1Tokens.forEach(token => {
    tf1.set(token, (tf1.get(token) || 0) + 1);
  });
  
  doc2Tokens.forEach(token => {
    tf2.set(token, (tf2.get(token) || 0) + 1);
  });
  
  // Calculate IDF (using 2 documents)
  const idf = new Map<string, number>();
  allTerms.forEach(term => {
    let docCount = 0;
    if (tf1.has(term)) docCount++;
    if (tf2.has(term)) docCount++;
    idf.set(term, Math.log(2 / docCount) + 1);
  });
  
  // Calculate TF-IDF vectors
  const doc1Vector: number[] = [];
  const doc2Vector: number[] = [];
  
  allTerms.forEach(term => {
    const tf1Val = (tf1.get(term) || 0) / (doc1Tokens.length || 1);
    const tf2Val = (tf2.get(term) || 0) / (doc2Tokens.length || 1);
    const idfVal = idf.get(term) || 1;
    
    doc1Vector.push(tf1Val * idfVal);
    doc2Vector.push(tf2Val * idfVal);
  });
  
  return { doc1Vector, doc2Vector };
}

/**
 * Calculate cosine similarity between two vectors
 */
export function cosineSimilarity(vec1: number[], vec2: number[]): number {
  if (vec1.length !== vec2.length || vec1.length === 0) return 0;
  
  let dotProduct = 0;
  let norm1 = 0;
  let norm2 = 0;
  
  for (let i = 0; i < vec1.length; i++) {
    dotProduct += vec1[i] * vec2[i];
    norm1 += vec1[i] * vec1[i];
    norm2 += vec2[i] * vec2[i];
  }
  
  const denominator = Math.sqrt(norm1) * Math.sqrt(norm2);
  
  if (denominator === 0) return 0;
  
  return dotProduct / denominator;
}

/**
 * Calculate skill match percentage
 */
export function calculateSkillMatch(cvSkills: string[], jdSkills: string[]): number {
  if (jdSkills.length === 0) return 100;
  
  const matchedSkills = cvSkills.filter(skill => 
    jdSkills.some(jdSkill => 
      skill.toLowerCase() === jdSkill.toLowerCase()
    )
  );
  
  return (matchedSkills.length / jdSkills.length) * 100;
}

/**
 * Find missing skills (skills in JD but not in CV)
 */
export function findMissingSkills(cvSkills: string[], jdSkills: string[]): string[] {
  const cvSkillsLower = cvSkills.map(s => s.toLowerCase());
  return jdSkills.filter(skill => !cvSkillsLower.includes(skill.toLowerCase()));
}

/**
 * Find matching skills (skills in both CV and JD)
 */
export function findMatchingSkills(cvSkills: string[], jdSkills: string[]): string[] {
  const jdSkillsLower = jdSkills.map(s => s.toLowerCase());
  return cvSkills.filter(skill => jdSkillsLower.includes(skill.toLowerCase()));
}

export interface AnalysisResult {
  // Overall scores
  overallScore: number;
  skillsScore: number;
  experienceScore: number;
  educationScore: number;
  
  // Extracted data
  cvSkills: string[];
  jdSkills: string[];
  matchingSkills: string[];
  missingSkills: string[];
  
  cvEducation: string[];
  jdEducation: string[];
  
  cvExperience: number | null;
  jdExperience: number | null;
  
  cvCertifications: string[];
  jdCertifications: string[];
  
  // Decision
  decision: 'strong' | 'moderate' | 'weak';
  decisionText: string;
  
  // Summary
  summary: string;
  strengths: string[];
  weaknesses: string[];
}

/**
 * Perform complete CV-JD analysis
 */
export function analyzeMatch(cvText: string, jdText: string): AnalysisResult {
  // Extract information from CV
  const cvSkills = extractSkills(cvText);
  const cvEducation = extractEducation(cvText);
  const cvExperience = extractExperience(cvText);
  const cvCertifications = extractCertifications(cvText);
  
  // Extract information from JD
  const jdSkills = extractSkills(jdText);
  const jdEducation = extractEducation(jdText);
  const jdExperience = extractExperience(jdText);
  const jdCertifications = extractCertifications(jdText);
  
  // Find matching and missing skills
  const matchingSkills = findMatchingSkills(cvSkills, jdSkills);
  const missingSkills = findMissingSkills(cvSkills, jdSkills);
  
  // Calculate TF-IDF and cosine similarity
  const cvTokens = preprocessText(cvText);
  const jdTokens = preprocessText(jdText);
  const { doc1Vector, doc2Vector } = calculateTFIDF(cvTokens, jdTokens);
  const textSimilarity = cosineSimilarity(doc1Vector, doc2Vector) * 100;
  
  // Calculate individual scores
  const skillsScore = jdSkills.length > 0 
    ? (matchingSkills.length / jdSkills.length) * 100 
    : 50;
  
  const experienceScore = calculateExperienceScore(cvExperience, jdExperience);
  const educationScore = calculateEducationScore(cvEducation, jdEducation);
  
  // Calculate overall score (weighted average)
  const overallScore = Math.round(
    (skillsScore * 0.4) + 
    (textSimilarity * 0.3) + 
    (experienceScore * 0.2) + 
    (educationScore * 0.1)
  );
  
  // Determine decision
  const { decision, decisionText } = getDecision(overallScore);
  
  // Generate strengths and weaknesses
  const strengths = generateStrengths(matchingSkills, cvExperience, cvEducation, cvCertifications);
  const weaknesses = generateWeaknesses(missingSkills, cvExperience, jdExperience);
  
  // Generate summary
  const summary = generateSummary(
    overallScore, 
    matchingSkills, 
    missingSkills, 
    cvExperience, 
    jdExperience,
    decision
  );
  
  return {
    overallScore,
    skillsScore: Math.round(skillsScore),
    experienceScore: Math.round(experienceScore),
    educationScore: Math.round(educationScore),
    cvSkills,
    jdSkills,
    matchingSkills,
    missingSkills,
    cvEducation,
    jdEducation,
    cvExperience,
    jdExperience,
    cvCertifications,
    jdCertifications,
    decision,
    decisionText,
    summary,
    strengths,
    weaknesses
  };
}

function calculateExperienceScore(cvExp: number | null, jdExp: number | null): number {
  if (jdExp === null) return 75; // No experience requirement
  if (cvExp === null) return 25; // Can't determine CV experience
  
  if (cvExp >= jdExp) return 100;
  if (cvExp >= jdExp * 0.75) return 75;
  if (cvExp >= jdExp * 0.5) return 50;
  return 25;
}

function calculateEducationScore(cvEdu: string[], jdEdu: string[]): number {
  if (jdEdu.length === 0) return 75;
  if (cvEdu.length === 0) return 25;
  
  const jdEduLower = jdEdu.map(e => e.toLowerCase());
  const matched = cvEdu.filter(e => jdEduLower.includes(e.toLowerCase()));
  
  return (matched.length / jdEdu.length) * 100;
}

function getDecision(score: number): { decision: 'strong' | 'moderate' | 'weak'; decisionText: string } {
  if (score >= 70) {
    return { decision: 'strong', decisionText: 'Strong Candidate - Recommend for Interview' };
  } else if (score >= 40) {
    return { decision: 'moderate', decisionText: 'Moderate Fit - Consider for Further Review' };
  } else {
    return { decision: 'weak', decisionText: 'Not a Strong Fit - May Not Meet Requirements' };
  }
}

function generateStrengths(
  matchingSkills: string[], 
  experience: number | null,
  education: string[],
  certifications: string[]
): string[] {
  const strengths: string[] = [];
  
  if (matchingSkills.length > 0) {
    strengths.push(`Possesses ${matchingSkills.length} relevant technical skills including ${matchingSkills.slice(0, 3).join(', ')}`);
  }
  
  if (experience !== null && experience > 0) {
    strengths.push(`Has ${experience}+ years of professional experience`);
  }
  
  if (education.length > 0) {
    strengths.push(`Educational background includes ${education.slice(0, 2).join(', ')}`);
  }
  
  if (certifications.length > 0) {
    strengths.push(`Holds certifications: ${certifications.slice(0, 2).join(', ')}`);
  }
  
  return strengths;
}

function generateWeaknesses(
  missingSkills: string[],
  cvExp: number | null,
  jdExp: number | null
): string[] {
  const weaknesses: string[] = [];
  
  if (missingSkills.length > 0) {
    weaknesses.push(`Missing ${missingSkills.length} required skills: ${missingSkills.slice(0, 4).join(', ')}`);
  }
  
  if (jdExp !== null && cvExp !== null && cvExp < jdExp) {
    weaknesses.push(`Experience gap: has ${cvExp} years vs. required ${jdExp} years`);
  } else if (jdExp !== null && cvExp === null) {
    weaknesses.push(`Unable to verify experience against ${jdExp} year requirement`);
  }
  
  return weaknesses;
}

function generateSummary(
  score: number,
  matchingSkills: string[],
  missingSkills: string[],
  cvExp: number | null,
  jdExp: number | null,
  decision: 'strong' | 'moderate' | 'weak'
): string {
  const parts: string[] = [];
  
  // Opening
  if (decision === 'strong') {
    parts.push(`This candidate shows strong alignment with the job requirements with an overall match score of ${score}%.`);
  } else if (decision === 'moderate') {
    parts.push(`This candidate shows moderate alignment with the job requirements, achieving a ${score}% match score.`);
  } else {
    parts.push(`This candidate has limited alignment with the job requirements, with only a ${score}% match score.`);
  }
  
  // Skills
  if (matchingSkills.length > 0) {
    parts.push(`The candidate demonstrates proficiency in ${matchingSkills.length} relevant skills${matchingSkills.length > 2 ? `, notably ${matchingSkills.slice(0, 3).join(', ')}` : ''}.`);
  }
  
  // Gaps
  if (missingSkills.length > 0) {
    parts.push(`Key skill gaps include ${missingSkills.slice(0, 3).join(', ')}${missingSkills.length > 3 ? ` and ${missingSkills.length - 3} others` : ''}.`);
  }
  
  // Experience
  if (cvExp !== null && jdExp !== null) {
    if (cvExp >= jdExp) {
      parts.push(`With ${cvExp}+ years of experience, the candidate meets or exceeds the ${jdExp}-year requirement.`);
    } else {
      parts.push(`The candidate has ${cvExp} years of experience, falling short of the ${jdExp}-year requirement.`);
    }
  }
  
  // Recommendation
  if (decision === 'strong') {
    parts.push('Recommend proceeding to interview stage.');
  } else if (decision === 'moderate') {
    parts.push('Consider for further evaluation or alternative positions.');
  } else {
    parts.push('May require additional screening or not recommended for this position.');
  }
  
  return parts.join(' ');
}
